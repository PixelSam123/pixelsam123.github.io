import{N as u,q as c,B as d,p as o,c as h,t as m,h as a,V as g,F as p,x as k,y as w}from"./index-BNJ3oQN6.js";/**
* @license lucide-solid v0.364.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/var v={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":2,"stroke-linecap":"round","stroke-linejoin":"round"},t=v,b=w("<svg>"),N=r=>r.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),f=r=>{const[e,n]=u(r,["color","size","strokeWidth","children","class","name","iconNode","absoluteStrokeWidth"]);return(()=>{var s=c(b);return d(s,o(t,{get width(){return e.size??t.width},get height(){return e.size??t.height},get stroke(){return e.color??t.stroke},get"stroke-width"(){return h(()=>!!e.absoluteStrokeWidth)()?Number(e.strokeWidth??t["stroke-width"])*24/Number(e.size):Number(e.strokeWidth??t["stroke-width"])},get class(){return`lucide lucide-${N(e?.name??"icon")} ${e.class!=null?e.class:""}`}},n),!0,!0),m(s,a(p,{get each(){return e.iconNode},children:([i,l])=>a(g,o({component:i},l))})),k(),s})()},x=f;export{x as I};
